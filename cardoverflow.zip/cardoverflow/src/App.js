import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

import Home from "./layout/Home";
function App() {
  return (
    <>
     <Home/>
    </>
  )
}
export default App;